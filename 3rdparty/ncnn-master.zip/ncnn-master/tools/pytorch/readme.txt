You can find pytorch2ncnn tool here

https://github.com/starimeL/PytorchConverter
https://github.com/inisis/brocolli

For newer version, pytorch already supports exporting to onnx out of box
You can follow the practical guide here

https://github.com/Tencent/ncnn/wiki/practical-pytorch-to-onnx-to-ncnn
