You can find darknet2ncnn tool here

https://github.com/xiangweizeng/darknet2ncnn
