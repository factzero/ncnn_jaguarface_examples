You can find tensorflow2ncnn tool here

https://github.com/hanzy88/ckpt2ncnn
https://github.com/hanzy88/tensorflow2ncnn
