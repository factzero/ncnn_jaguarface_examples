// Tencent is pleased to support the open source community by making ncnn available.
//
// Copyright (C) 2019 THL A29 Limited, a Tencent company. All rights reserved.
//
// Licensed under the BSD 3-Clause License (the "License"); you may not use this file except
// in compliance with the License. You may obtain a copy of the License at
//
// https://opensource.org/licenses/BSD-3-Clause
//
// Unless required by applicable law or agreed to in writing, software distributed
// under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
// CONDITIONS OF ANY KIND, either express or implied. See the License for the
// specific language governing permissions and limitations under the License.

#include "innerproduct_vulkan.h"
#include <algorithm>
#include "layer_type.h"

namespace ncnn {

DEFINE_LAYER_CREATOR(InnerProduct_vulkan)

InnerProduct_vulkan::InnerProduct_vulkan()
{
    support_vulkan = true;

    flatten = 0;

    pipeline_innerproduct = 0;
    pipeline_innerproduct_pack4 = 0;
    pipeline_innerproduct_pack1to4 = 0;
    pipeline_innerproduct_pack4to1 = 0;
    pipeline_innerproduct_pack8 = 0;
    pipeline_innerproduct_pack1to8 = 0;
    pipeline_innerproduct_pack4to8 = 0;
    pipeline_innerproduct_pack8to4 = 0;
    pipeline_innerproduct_pack8to1 = 0;
}

int InnerProduct_vulkan::create_pipeline(const Option& opt)
{
    {
        flatten = ncnn::create_layer(ncnn::LayerType::Flatten);
        flatten->vkdev = vkdev;

        ncnn::ParamDict pd;

        flatten->load_param(pd);

        flatten->create_pipeline(opt);
    }

    int num_input = weight_data_size / num_output;

    int elempack = opt.use_shader_pack8 && num_input % 8 == 0 ? 8 : num_input % 4 == 0 ? 4 : 1;
    int out_elempack = opt.use_shader_pack8 && num_output % 8 == 0 ? 8 : num_output % 4 == 0 ? 4 : 1;

    std::vector<vk_specialization_type> specializations(4);
    specializations[0].i = bias_term;
    specializations[1].i = activation_type;
    specializations[2].f = activation_params.w == 1 ? activation_params[0] : 0.f;
    specializations[3].f = activation_params.w == 2 ? activation_params[1] : 0.f;

    // pack1
    if (elempack == 1 && out_elempack == 1)
    {
        pipeline_innerproduct = new Pipeline(vkdev);
        pipeline_innerproduct->set_optimal_local_size_xyz(num_output, 1, 1);
        pipeline_innerproduct->create("innerproduct", opt, specializations, 4, 10);
    }

    // pack4
    if (elempack == 4 && out_elempack == 4)
    {
        pipeline_innerproduct_pack4 = new Pipeline(vkdev);
        pipeline_innerproduct_pack4->set_optimal_local_size_xyz(num_output / 4, 1, 1);
        pipeline_innerproduct_pack4->create("innerproduct_pack4", opt, specializations, 4, 10);
    }

    // pack1to4
    if (elempack == 1 && out_elempack == 4)
    {
        pipeline_innerproduct_pack1to4 = new Pipeline(vkdev);
        pipeline_innerproduct_pack1to4->set_optimal_local_size_xyz(num_output / 4, 1, 1);
        pipeline_innerproduct_pack1to4->create("innerproduct_pack1to4", opt, specializations, 4, 10);
    }

    // pack4to1
    if (elempack == 4 && out_elempack == 1)
    {
        pipeline_innerproduct_pack4to1 = new Pipeline(vkdev);
        pipeline_innerproduct_pack4to1->set_optimal_local_size_xyz(num_output, 1, 1);
        pipeline_innerproduct_pack4to1->create("innerproduct_pack4to1", opt, specializations, 4, 10);
    }

    // pack8
    if (elempack == 8 && out_elempack == 8)
    {
        pipeline_innerproduct_pack8 = new Pipeline(vkdev);
        pipeline_innerproduct_pack8->set_optimal_local_size_xyz(num_output / 8, 1, 1);
        pipeline_innerproduct_pack8->create("innerproduct_pack8", opt, specializations, 4, 10);
    }

    // pack1to8
    if (elempack == 1 && out_elempack == 8)
    {
        pipeline_innerproduct_pack1to8 = new Pipeline(vkdev);
        pipeline_innerproduct_pack1to8->set_optimal_local_size_xyz(num_output / 8, 1, 1);
        pipeline_innerproduct_pack1to8->create("innerproduct_pack1to8", opt, specializations, 4, 10);
    }

    // pack4to8
    if (elempack == 4 && out_elempack == 8)
    {
        pipeline_innerproduct_pack4to8 = new Pipeline(vkdev);
        pipeline_innerproduct_pack4to8->set_optimal_local_size_xyz(num_output / 8, 1, 1);
        pipeline_innerproduct_pack4to8->create("innerproduct_pack4to8", opt, specializations, 4, 10);
    }

    // pack8to4
    if (elempack == 8 && out_elempack == 4)
    {
        pipeline_innerproduct_pack8to4 = new Pipeline(vkdev);
        pipeline_innerproduct_pack8to4->set_optimal_local_size_xyz(num_output / 4, 1, 1);
        pipeline_innerproduct_pack8to4->create("innerproduct_pack8to4", opt, specializations, 4, 10);
    }

    // pack8to1
    if (elempack == 8 && out_elempack == 1)
    {
        pipeline_innerproduct_pack8to1 = new Pipeline(vkdev);
        pipeline_innerproduct_pack8to1->set_optimal_local_size_xyz(num_output, 1, 1);
        pipeline_innerproduct_pack8to1->create("innerproduct_pack8to1", opt, specializations, 4, 10);
    }

    return 0;
}

int InnerProduct_vulkan::destroy_pipeline(const Option& opt)
{
    if (flatten)
    {
        flatten->destroy_pipeline(opt);
        delete flatten;
        flatten = 0;
    }

    delete pipeline_innerproduct;
    pipeline_innerproduct = 0;

    delete pipeline_innerproduct_pack4;
    pipeline_innerproduct_pack4 = 0;

    delete pipeline_innerproduct_pack1to4;
    pipeline_innerproduct_pack1to4 = 0;

    delete pipeline_innerproduct_pack4to1;
    pipeline_innerproduct_pack4to1 = 0;

    delete pipeline_innerproduct_pack8;
    pipeline_innerproduct_pack8 = 0;

    delete pipeline_innerproduct_pack1to8;
    pipeline_innerproduct_pack1to8 = 0;

    delete pipeline_innerproduct_pack4to8;
    pipeline_innerproduct_pack4to8 = 0;

    delete pipeline_innerproduct_pack8to4;
    pipeline_innerproduct_pack8to4 = 0;

    delete pipeline_innerproduct_pack8to1;
    pipeline_innerproduct_pack8to1 = 0;

    return 0;
}

int InnerProduct_vulkan::upload_model(VkTransfer& cmd, const Option& opt)
{
    int num_input = weight_data_size / num_output;

    int elempack = opt.use_shader_pack8 && num_input % 8 == 0 ? 8 : num_input % 4 == 0 ? 4 : 1;
    int out_elempack = opt.use_shader_pack8 && num_output % 8 == 0 ? 8 : num_output % 4 == 0 ? 4 : 1;

    // src = inch-outch
    // dst = pa-pb-inch/pa-outch/pb
    Mat weight_data_packed;
    {
        Mat weight_data_r2 = weight_data.reshape(num_input, num_output);

        weight_data_packed.create(num_input/elempack, num_output/out_elempack, (size_t)4*elempack*out_elempack, elempack*out_elempack);

        for (int q=0; q+(out_elempack-1)<num_output; q+=out_elempack)
        {
            float* g00 = weight_data_packed.row(q/out_elempack);

            for (int p=0; p+(elempack-1)<num_input; p+=elempack)
            {
                for (int i=0; i<out_elempack; i++)
                {
                    const float* k0 = weight_data_r2.row(q+i);
                    k0 += p;

                    for (int j=0; j<elempack; j++)
                    {
                        g00[0] = k0[j];

                        g00++;
                    }
                }
            }
        }
    }

    cmd.record_upload(weight_data_packed, weight_data_gpu, opt);

    if (bias_term)
    {
        cmd.record_upload(bias_data, bias_data_gpu, opt);
    }

    return 0;
}

int InnerProduct_vulkan::forward(const VkMat& bottom_blob, VkMat& top_blob, VkCompute& cmd, const Option& opt) const
{
    // flatten
    VkMat bottom_blob_flattened = bottom_blob;
    {
        Option opt_flatten = opt;
        opt_flatten.blob_vkallocator = opt.workspace_vkallocator;

        flatten->forward(bottom_blob, bottom_blob_flattened, cmd, opt_flatten);
    }

    size_t elemsize = bottom_blob_flattened.elemsize;
    int elempack = bottom_blob_flattened.elempack;

    int out_elempack = opt.use_shader_pack8 && num_output % 8 == 0 ? 8 : num_output % 4 == 0 ? 4 : 1;
    size_t out_elemsize = elemsize / elempack * out_elempack;

    if (opt.use_fp16_packed && !opt.use_fp16_storage)
    {
        if (out_elempack == 8) out_elemsize = 8*2u;
        if (out_elempack == 4) out_elemsize = 4*2u;
        if (out_elempack == 1) out_elemsize = 4u;
    }

    top_blob.create(num_output / out_elempack, out_elemsize, out_elempack, opt.blob_vkallocator, opt.staging_vkallocator);
    if (top_blob.empty())
        return -100;

    std::vector<VkMat> bindings(4);
    bindings[0] = bottom_blob_flattened;
    bindings[1] = top_blob;
    bindings[2] = weight_data_gpu;
    bindings[3] = bias_term ? bias_data_gpu : bindings[2];// TODO use dummy buffer

    std::vector<vk_constant_type> constants(10);
    constants[0].i = bottom_blob_flattened.dims;
    constants[1].i = bottom_blob_flattened.w;
    constants[2].i = bottom_blob_flattened.h;
    constants[3].i = bottom_blob_flattened.c;
    constants[4].i = bottom_blob_flattened.cstep;
    constants[5].i = top_blob.dims;
    constants[6].i = top_blob.w;
    constants[7].i = top_blob.h;
    constants[8].i = top_blob.c;
    constants[9].i = top_blob.cstep;

    const Pipeline* pipeline = 0;
    if (elempack == 1 && out_elempack == 1)
    {
        pipeline = pipeline_innerproduct;
    }
    else if (elempack == 4 && out_elempack == 4)
    {
        pipeline = pipeline_innerproduct_pack4;
    }
    else if (elempack == 1 && out_elempack == 4)
    {
        pipeline = pipeline_innerproduct_pack1to4;
    }
    else if (elempack == 4 && out_elempack == 1)
    {
        pipeline = pipeline_innerproduct_pack4to1;
    }
    else if (elempack == 8 && out_elempack == 8)
    {
        pipeline = pipeline_innerproduct_pack8;
    }
    else if (elempack == 1 && out_elempack == 8)
    {
        pipeline = pipeline_innerproduct_pack1to8;
    }
    else if (elempack == 4 && out_elempack == 8)
    {
        pipeline = pipeline_innerproduct_pack4to8;
    }
    else if (elempack == 8 && out_elempack == 4)
    {
        pipeline = pipeline_innerproduct_pack8to4;
    }
    else if (elempack == 8 && out_elempack == 1)
    {
        pipeline = pipeline_innerproduct_pack8to1;
    }

    cmd.record_pipeline(pipeline, bindings, constants, top_blob);

    return 0;
}

} // namespace ncnn
